#include <iostream>
#include <vector>

std::vector<int> subarraySum(std::vector<int>& nums, int targetSum) {
    int N = nums.size();
    int left = 0, right = 0;
    int currentSum = nums[0];

    while (right < N && left <= right) {
        if (currentSum == targetSum) {
            return {left + 1, right + 1};
        }
        if (currentSum < targetSum) {
            right++;
            if (right < N)
                currentSum += nums[right];
        }
        else {
            currentSum -= nums[left];
            left++;
        }
    }

    return {-1};
}

int main() {
    int N;
    std::cout << "Enter the size of the array: ";
    std::cin >> N;

    std::vector<int> A(N);
    std::cout << "Enter the elements of the array: ";
    for (int i = 0; i < N; i++) {
        std::cin >> A[i];
    }

    int targetSum;
    std::cout << "Enter the target sum: ";
    std::cin >> targetSum;

    std::vector<int> result = subarraySum(A, targetSum);

    if (result[0] == -1) {
        std::cout << "No subarray found with the given sum.\n";
    } else {
        std::cout << "Left index: " << result[0] << ", Right index: " << result[1] << std::endl;
    }

    return 0;
}


